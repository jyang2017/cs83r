=begin
Author: Fedorov Igor
Course Number: CS83R_1724
Date: September 26, 2015
Purpose: Display on screen in large letters the street where I grew up.
Input: None
Output: generates the output by using five puts statements.
=end

puts "\nPPPP   OOO  DDDD  M   M  OOO   SSSS K  K   OOO   V   V N   N  AAA  Y   Y  AAA      SSSS  TTTTT  "
puts   "P   P O   O D   D MM MM O   O S     K K   O   O  V   V NN  N A   A  Y Y  A   A    S        T    "   
puts   "PPPP  O   O D   D M M M O   O SSSSS KKK   O   O  V   V N N N AAAAA   Y   AAAAA    SSSSS    T    "
puts   "P     O   O D   D M   M O   O     S K  K  O   O   V V  N  NN A   A   Y   A   A        S    T    "    
puts   "P      OOO  DDDD  M   M  OOO  SSSS  K   K  OOO     V   N   N A   A   Y   A   A    SSSS     T   ." 