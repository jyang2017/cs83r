require 'test_helper'

class PortfolioHistoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
