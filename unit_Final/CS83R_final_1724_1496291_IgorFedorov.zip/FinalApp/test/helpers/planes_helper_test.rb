require 'test_helper'

class PlanesHelperTest < ActionView::TestCase
end
