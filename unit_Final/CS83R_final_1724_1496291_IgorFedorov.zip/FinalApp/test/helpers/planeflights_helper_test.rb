require 'test_helper'

class PlaneflightsHelperTest < ActionView::TestCase
end
