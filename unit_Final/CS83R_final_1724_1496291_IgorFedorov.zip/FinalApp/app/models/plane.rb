class Plane < ActiveRecord::Base
end
