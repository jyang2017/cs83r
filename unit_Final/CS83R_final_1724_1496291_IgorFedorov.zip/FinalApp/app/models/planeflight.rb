class Planeflight < ActiveRecord::Base
  belongs_to :plane
end
