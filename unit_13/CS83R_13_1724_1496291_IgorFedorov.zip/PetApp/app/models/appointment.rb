class Appointment < ActiveRecord::Base
end
